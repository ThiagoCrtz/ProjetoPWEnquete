﻿namespace ProjetoPWEnquete.ViewsModels
{
    public class ResultadoGraficoViewModel
    {
        public string[] Labels { get; set; } = [];
        public int[] Votos { get; set; } = [];
        public string TituloEnquete { get; set; } = string.Empty;
    }

}
